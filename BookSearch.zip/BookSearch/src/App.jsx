import React, { useState } from 'react';
import './App.css';
import Select from 'react-select';

import {
  InputGroup,
  Input,
  InputGroupAddon,
  Button,
  FormGroup,
  Label,
  Spinner
} from 'reactstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import axios from 'axios';
import BookCard from './BookCard.jsx';
import Form from 'reactstrap/lib/Form';
import { cloneElement } from 'react';


function App() {
  // States
  //let testState = 2;
  const [maxResults, setMaxResults] = useState(10);
  const [startIndex, setStartIndex] = useState(1);
  //const handleClick = () => setStartIndex(startIndex + 1);

  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [cards, setCards] = useState([]);

  // Handle Search
  const handleSubmit = () => {

    //if(global.config.i18n.welcome.string1 === '1' || global.config.i18n.welcome.string1 === '2') {
    
    
      global.config.i18n.welcome.en5 = 2

    setLoading(true);
    if (maxResults > 40 || maxResults < 1) {
      toast.error('max results must be between 1 and 40');
    } else {
      //1st axios, it goes through 2 times, the 1st time will get the value, the 2nd one will also output it?
      axios
        .get(
          `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=${maxResults}&startIndex=${startIndex}`
        )
        .then(res => {
          if (startIndex >= res.data.totalItems || startIndex < 1) {
            toast.error(
              `max reults must be between 1 and ${res.data.totalItems}`
            );
          } else {
            if (res.data.items.length > 0) {
              setCards(res.data.items);
              setLoading(false);
            }
          }
        })
        .catch(err => {
          setLoading(true);
          console.log(err.response);          
        });
    }

   // }
   
  };

  var imgArray = new Array()

  function nextImage(){
    var img = document.getElementById("mainImage");
    for(var i = 0; i < imgArray.length;i++){
        if(imgArray[i].src == img.src){
            if(i === imgArray.length){
                document.getElementById("mainImage").src = imgArray[0].src;
                break;
            }
            document.getElementById("mainImage").src = imgArray[i+1].src;
            break;
        }
    }
}

  const handleSort = () =>  {
    //setStartIndex(startIndex + 1)
    //setMaxResults(1 )
    global.config.i18n.welcome.en4[0] = 111
    const sb = document.querySelector('#framework')
    
    //if value = 0 original 
    //if value = 1 ascending sort
    //if value = 2 desending sort 


    global.config.i18n.welcome.string1 = sb.value
    console.log('THIS VALUE', global.config.i18n.welcome.string1) 
 //output nothing without this
    // 2nd axios
    global.config.i18n.welcome.en5 = 1
    axios
        .get(
          `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=${maxResults}&startIndex=${startIndex}`
        )
        .then(res => {
           
            if (res.data.items.length > 0) {
              setCards(res.data.items);
              setLoading(false);
            }   
        })
        .catch(err => {
          setLoading(true);
          console.log(err.response);          
        });
    
      /*onclick = (event) => {
        event.preventDefault();
        
        //alert(sb.value);
        console.log(sb.value);
        
        //testState = 3;
        //console.log(testState)
        
        //Index to for loop set equally
        /**/
        //For loop index to display correct
        //maybe go to handlesubmit after clicking will display what ideas(if option ascending, descending => display)

    /*
    //for(let k=0; k < 10; k++) {
     setLoading(true);
    if (maxResults > 40 || maxResults < 1) {
      toast.error('max results must be between 1 and 40');
    } else {
      axios
        .get(
          `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=${10}&startIndex=${global.config.i18n.welcome.en2[0]+1}`
        )
        .then(res => {
          if (startIndex >= res.data.totalItems || startIndex < 1) {
            toast.error(
              `max reults must be between 1 and ${res.data.totalItems}`
            );
          } else {
            if (res.data.items.length > 0) {
              setCards(res.data.items);
              setLoading(false);
            }
          }
        })
        .catch(err => {
          setLoading(true);
          console.log(err.response);      
        });
    }
    //}
    */  

  };

  
  // Main Show Case
  const mainHeader = () => {
    
    return (
      <div className='main-image d-flex justify-content-center align-items-center flex-column'>
        {/* Overlay */}
        <div className='filter'></div>
        <h1
          className='display-2 text-center text-white mb-3'
          style={{ zIndex: 2 }}
        >
          Google Books
        </h1>
        <div style={{ width: '60%', zIndex: 2 }}>
          <InputGroup size='lg' className='mb-3'>
            <Input
              placeholder='Book Search'
              value={query}
              onChange={e => setQuery(e.target.value)}
            />
            <InputGroupAddon addonType='append'>
              <Button color='secondary' onClick={handleSubmit}>
                <i className='fas fa-search'></i>
              </Button>
            </InputGroupAddon>


          </InputGroup>


          <div className='d-flex text-white justify-content-center'>
            <FormGroup>
            <Label for="framework">Sort Order:</Label>
            <select onChange={handleSort} id="framework">
                
                <option value="0">Order Added</option>
                <option value="1">Title Ascending</option>
                <option value="2">Title Descending</option>
            </select>
            
            
            </FormGroup>
          </div>
          

          <div className='d-flex text-white justify-content-center'>
            <FormGroup >
              <Label for='maxResults'>Max Results</Label>
              <Input
                type='number'
                id='maxResults'
                placeholder='Max Results'
                value={maxResults}
                onChange={e => setMaxResults(e.target.value)}
              />
            </FormGroup>

            
            <FormGroup className='ml-5'>
              <Label for='startIndex'>Start Index</Label>
              <Input
                type='number'
                id='startIndex'
                placeholder='Start Index'
                value={startIndex}
                onChange={e => setStartIndex(e.target.value)}
              />
            </FormGroup>
          </div>
        </div>
      </div>
    );
  };


  function swap(json){
    var ret = {};
    for(var key in json){
      ret[json[key]] = key;
    }
    return ret;
  }

  const handleCards = () => {
    if (loading) {
      return (
        <div className='d-flex justify-content-center mt-3'>
          <Spinner style={{ width: '3rem', height: '3rem' }} />
        </div>
      );
    } else {
     
      

        if (global.config.i18n.welcome.en4[0] == 111) {
        console.log("YES")  
        var cards2 = {};
        for (var i in cards)
        cards2[i] = cards[i];
        for(let i=0; i < maxResults; i++) {
          //console.log('HEYYY', cards[i], cards[global.config.i18n.welcome.en2[i]])
          cards[i] = cards2[global.config.i18n.welcome.en2[i]]
          
          //console.log('HEYYY', i, global.config.i18n.welcome.en2[i])
          //console.log('HEYYY', cards[i], cards[global.config.i18n.welcome.en2[i]])
        }
        //for(let k = 0; k < 10; k++) {}
        //const items = cards.map((item, i) => {
        const items = cards.map((item, i) => {
          console.log(i)
          let thumbnail = '';
          let connect = ' ' + [i];
  
          //iterate through a map?
                
    
          
              
          
          if (item.volumeInfo.imageLinks) {
            thumbnail = item.volumeInfo.imageLinks.thumbnail;
          }
  
          let test = [];
         
         
          return (
            <div className='col-lg-4 mb-3' key={item.id}>
              
              <BookCard
              
                thumbnail={thumbnail}
                
                pageCount={item.volumeInfo.pageCount}
                title={item.volumeInfo.title}
                
                language={item.volumeInfo.language}
                authors={item.volumeInfo.authors}
                publisher={item.volumeInfo.publisher}
                description={item.volumeInfo.description}
                previewLink={item.volumeInfo.previewLink}
                infoLink={item.volumeInfo.infoLink}
                connect= {connect}
                number= {i}
                test = {item.volumeInfo.title}
              />             
              
              
            </div>
            
            

          );

          
            
        });
        return (
          <div className='container my-5'>
            <div className='row'> {items}</div>
          </div>
        );
      }

      

      else {

      const items = cards.map((item, i) => {
        
        console.log(i)
        let thumbnail = '';
        let connect = ' ' + [i];

   
        
        if (item.volumeInfo.imageLinks) {
          thumbnail = item.volumeInfo.imageLinks.thumbnail;
        }

       
       
        return (

          <div className='col-lg-4 mb-3' key={item.id}>
            
            <BookCard            
              thumbnail={thumbnail}
              pageCount={item.volumeInfo.pageCount}
              title={item.volumeInfo.title}
              language={item.volumeInfo.language}
              authors={item.volumeInfo.authors}
              publisher={item.volumeInfo.publisher}
              description={item.volumeInfo.description}
              previewLink={item.volumeInfo.previewLink}
              infoLink={item.volumeInfo.infoLink}
              connect= {connect}
              number= {i}
            />
                                                
          </div>
        );

        

      } 
      );
      return (
        <div className='container my-5'>
          <div className='row'>{items}</div>
        </div>
      );
    }
  }
  };
  return (
    <div className='w-100 h-100'>
      {mainHeader()}
      {handleCards()}
   
      <ToastContainer />
    </div>
  );
}

export default App;
